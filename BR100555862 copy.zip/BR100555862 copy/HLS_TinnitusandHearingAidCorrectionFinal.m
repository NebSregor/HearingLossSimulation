%Hearing Loss Simulation with Tinnitus - For general use.

% Audio input - Sound source can be changed by altering .wav file from
% the selection presented in the sound sources folder.

[in,Fs] = audioread('FB_male_female_single-talk_seq.wav');

%[in2,Fs] = audioread('FB_male_female_single-talk_seq.wav'); %Unprocessed Signal
%UnprocessedSignal = in2;

in_L = in;
in_R = in;

%Audiogram Match: Change Peak Gain values to alter/match audiogram
%results. Be aware that the nature of MATLABS MPEQ may mean that you have
%to apply trial and error to replicate the audiogram most accurately. Use
%MPEQ plot beow to help make adjustments where necessary.

Audiogram.L = multibandParametricEQ('NumEQBands',10,...
    'HasHighShelfFilter',true,...
    'HighShelfCutoff',8000,...
    'HasLowpassFilter',...
    true,...
    'LowpassCutoff',8000,...
    'LowpassSlope',24,...
    'Frequencies',[125,250,500,1000,1500,2000,3000,4000,6000,8000],...
    'QualityFactors',[2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3],...
    'PeakGains',[0 -5 -10 0 0 -15 -55 -30 -35 -25]);

Audiogram.R = multibandParametricEQ('NumEQBands',10,...
    'HasHighShelfFilter',true,...
    'HighShelfCutoff',8000,...
    'HasLowpassFilter',...
    true,...
    'LowpassCutoff',8000,...
    'LowpassSlope',24,...
    'Frequencies',[125,250,500,1000,1500,2000,3000,4000,6000,8000],...
    'QualityFactors',[2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3,2.3],...
    'PeakGains',[0 -10 -10 0 -5 -20 -65 -55 -35 -30]);

Audiogram.Match_L = Audiogram.L(in_L);
Audiogram.Match_R = Audiogram.R(in_R);

Amatch = (Audiogram.Match_L+Audiogram.Match_R);

%Visualize audiogram MPEQ for Left and Right ear (remove '%' signs below)

%mPEQL = Audiogram.NIHLL;
%mPEQR = Audiogram.NIHLR;
%visualize(mPEQL)
%visualize(mPEQL)

%Gammatone filter

Audiogram.FiltBank_L = gammatoneFilterBank([20 16000 ],32,Fs);
Audiogram.FiltBank_R = gammatoneFilterBank([20 16000 ],32,Fs);

gammaout_L = Audiogram.FiltBank_L(in_L);
gammaout_R = Audiogram.FiltBank_L(in_R);

%Gamma Split Left Ear

gammaout_L_ch1 = sum(gammaout_L(:,1:4),2); % 0-180 Hz (Band1)
gammaout_L_ch2 = sum(gammaout_L(:,5:8),2); % 200 - 400 Hz (Band1)
gammaout_L_ch3 = sum(gammaout_L(:,9:13),2); % 500 - 1.1 kHz (Band2)
gammaout_L_ch4 = sum(gammaout_L(:,14:15),2); % 1.2 - 1.5 kHz (Band3)
gammaout_L_ch5 = sum(gammaout_L(:,16:17),2); % 1.6 - 2 kHz (Band4)
gammaout_L_ch6 = sum(gammaout_L(:,18:19),2); % 2 - 2.7 kHz (Band5)
gammaout_L_ch7 = sum(gammaout_L(:,20:21),2); % 3 - 3.5 kHz (Band6)
gammaout_L_ch8 = sum(gammaout_L(:,22:24),2); % 4 - 5.5 kHz (Band7)
gammaout_L_ch9 = sum(gammaout_L(:,25:26),2); % 6 - 7.5 kHz (Band8)
gammaout_L_ch10 = sum(gammaout_L(:,27:29),2);% 8 - 11 kHz (Band9)
gammaout_L_ch11 = sum(gammaout_L(:,30:32),2);% 12 - 16 kHz (Band9)

%Gamma Split Right Ear

gammaout_R_ch1 = sum(gammaout_R(:,1:4),2); % 0-180 Hz 
gammaout_R_ch2 = sum(gammaout_R(:,5:8),2); % 200 - 400 Hz
gammaout_R_ch3 = sum(gammaout_R(:,9:13),2); % 500 - 1.1 kHz
gammaout_R_ch4 = sum(gammaout_R(:,14:15),2); % 1.2 - 1.5 kHz
gammaout_R_ch5 = sum(gammaout_R(:,16:17),2); % 1.6 - 2 kHz
gammaout_R_ch6 = sum(gammaout_R(:,18:19),2); % 2 - 2.7 kHz
gammaout_R_ch7 = sum(gammaout_R(:,20:21),2); % 3 - 3.5 kHz
gammaout_R_ch8 = sum(gammaout_R(:,22:24),2); % 4 - 5.5 kHz
gammaout_R_ch9 = sum(gammaout_R(:,25:26),2); % 6 - 7.5 kHz
gammaout_R_ch10 = sum(gammaout_R(:,27:29),2);% 8 - 11 kHz
gammaout_R_ch11 = sum(gammaout_R(:,30:32),2);% 12 - 16 kHz

%Gamma Split Outputs

%Gamma Output Left Ear

gammaout_L_band1 = Audiogram.Match_L+gammaout_L_ch1+gammaout_L_ch2; % 0-180 Hz (Band1) & % 200 - 400 Hz (Band1)
gammaout_L_band2 = Audiogram.Match_L+gammaout_L_ch3; % 500 - 1.1 kHz (Band2)
gammaout_L_band3 = Audiogram.Match_L+gammaout_L_ch4; % 1.2 - 1.5 kHz (Band3)
gammaout_L_band4 = Audiogram.Match_L+gammaout_L_ch5; % 1.6 - 2 kHz (Band4)
gammaout_L_band5 = Audiogram.Match_L+gammaout_L_ch6; % 2 - 2.7 kHz (Band5)
gammaout_L_band6 = Audiogram.Match_L+gammaout_L_ch7; % 3 - 3.5 kHz (Band6)
gammaout_L_band7 = Audiogram.Match_L+gammaout_L_ch8; % 4 - 5.5 kHz (Band7)
gammaout_L_band8 = Audiogram.Match_L+gammaout_L_ch9; % 6 - 7.5 kHz (Band8)
gammaout_L_band9 = Audiogram.Match_L+gammaout_L_ch10+gammaout_L_ch11; % 8 - 11 kHz (Band9) & % 12 - 16 kHz (Band9)

%Gamma Output Right Ear

gammaout_R_band1 = Audiogram.Match_R+gammaout_R_ch1+gammaout_R_ch2;
gammaout_R_band2 = Audiogram.Match_R+gammaout_R_ch3;
gammaout_R_band3 = Audiogram.Match_R+gammaout_R_ch4;
gammaout_R_band4 = Audiogram.Match_R+gammaout_R_ch5;
gammaout_R_band5 = Audiogram.Match_R+gammaout_R_ch6;
gammaout_R_band6 = Audiogram.Match_R+gammaout_R_ch7;
gammaout_R_band7 = Audiogram.Match_R+gammaout_R_ch8;
gammaout_R_band8 = Audiogram.Match_R+gammaout_R_ch9;
gammaout_R_band9 = Audiogram.Match_R+gammaout_R_ch10+gammaout_R_ch11;


%GATE Function (x,Fs,Threshold,Ratio,attackTime,realeaseTime) (Tarr, 2019)

%Gate

% Parameters for Gate - Thresholds should match peak gains MPEQ values to mimic
% permanent threshold shift caused by cochlea damage (starting from from 250 Hz).

% Initialize separate attack and release times
attackTime = 0.005;  % time in seconds
releaseTime = 0.4;  % time in seconds

Gate_out_L_band1 = expander(gammaout_L_band1,Fs,-5,30,attackTime,releaseTime); % 0-180 Hz (Band1) & % 200 - 400 Hz (Band1)
Gate_out_L_band2 = expander(gammaout_L_band2,Fs,-10,30,attackTime,releaseTime); % 500 - 1.1 kHz (Band2)
Gate_out_L_band3 = expander(gammaout_L_band3,Fs,-0,30,attackTime,releaseTime); % 1.2 - 1.5 kHz (Band3)
Gate_out_L_band4 = expander(gammaout_L_band4,Fs,-0,30,attackTime,releaseTime); % 1.6 - 2 kHz (Band4)
Gate_out_L_band5 = expander(gammaout_L_band5,Fs,-15,30,attackTime,releaseTime); % 2 - 2.7 kHz (Band5)
Gate_out_L_band6 = expander(gammaout_L_band6,Fs,-55,30,attackTime,releaseTime); % 3 - 3.5 kHz (Band6)
Gate_out_L_band7 = expander(gammaout_L_band7,Fs,-30,30,attackTime,releaseTime); % 4 - 5.5 kHz (Band7)
Gate_out_L_band8 = expander(gammaout_L_band8,Fs,-35,30,attackTime,releaseTime); % 6 - 7.5 kHz (Band8)
Gate_out_L_band9 = expander(gammaout_L_band9,Fs,-25,30,attackTime,releaseTime); % 8 - 11 kHz (Band9) & % 12 - 16 kHz (Band9)

Gate_out_R_band1 = expander(gammaout_R_band1,Fs,-10,30,attackTime,releaseTime);
Gate_out_R_band2 = expander(gammaout_R_band2,Fs,-10,30,attackTime,releaseTime);
Gate_out_R_band3 = expander(gammaout_R_band3,Fs,-0,30,attackTime,releaseTime);
Gate_out_R_band4 = expander(gammaout_R_band4,Fs,-5,30,attackTime,releaseTime);
Gate_out_R_band5 = expander(gammaout_R_band5,Fs,-20,30,attackTime,releaseTime);
Gate_out_R_band6 = expander(gammaout_R_band6,Fs,-65,30,attackTime,releaseTime);
Gate_out_R_band7 = expander(gammaout_R_band7,Fs,-55,30,attackTime,releaseTime);
Gate_out_R_band8 = expander(gammaout_R_band8,Fs,-35,30,attackTime,releaseTime);
Gate_out_R_band9 = expander(gammaout_R_band9,Fs,-30,30,attackTime,releaseTime);


% Compressor Function (x,Fs,Threshold,Ratio,attackTime,realeaseTime)
% (Tarr,2019)

%Compressor Ratio Parameters - Thresholds/Ratios taken from Kates and Prabhu,
%2018)

%Threshold Parameter can be changed to mimic severeity bands and show the
%degree of hearing loss present:

%Normal = 0 - 25 dB
%Mild = 25 - 40 dB
%Moderate = 40 - 60 dB
%Severe = 60 - 80 dB
%Severe to Profound = 80 - 90 dB
%Profound = 90 dB and greater

% Initialize separate attack and release times
attackTime = 0.05;  % time in seconds
releaseTime = 0.25;  % time in seconds

%Left Ear Multiband Dynamic Range Compression 

compressor_out_L_band1 = compressor(Gate_out_L_band1,Fs,-10,1.25,attackTime,releaseTime); % 0-180 Hz (Band1) & % 200 - 400 Hz (Band1)
compressor_out_L_band2 = compressor(Gate_out_L_band2,Fs,-30,1.5,attackTime,releaseTime); % 500 - 1.1 kHz (Band2)
compressor_out_L_band3 = compressor(Gate_out_L_band3,Fs,-60,1.75,attackTime,releaseTime); % 1.2 - 1.5 kHz (Band3)
compressor_out_L_band4 = compressor(Gate_out_L_band4,Fs,-40,2,attackTime,releaseTime); % 1.6 - 2 kHz (Band4)
compressor_out_L_band5 = compressor(Gate_out_L_band5,Fs,-30,2.25,attackTime,releaseTime); % 2 - 2.7 kHz (Band5)
compressor_out_L_band6 = compressor(Gate_out_L_band6,Fs,-30,2.5,attackTime,releaseTime); % 3 - 3.5 kHz (Band6)
compressor_out_L_band7 = compressor(Gate_out_L_band7,Fs,-60,2.75,attackTime,releaseTime); % 4 - 5.5 kHz (Band7)
compressor_out_L_band8 = compressor(Gate_out_L_band8,Fs,-40,3.5,attackTime,releaseTime); % 6 - 7.5 kHz (Band8)
compressor_out_L_band9 = compressor(Gate_out_L_band9,Fs,-40,3.5,attackTime,releaseTime); % 8 - 11 kHz (Band9) & % 12 - 16 kHz (Band9)

%Right Ear Multiband Dynamic Range Compression 

compressor_out_R_band1 = compressor(Gate_out_R_band1,Fs,-10,1.25,attackTime,releaseTime);
compressor_out_R_band2 = compressor(Gate_out_R_band2,Fs,-30,1.5,attackTime,releaseTime);
compressor_out_R_band3 = compressor(Gate_out_R_band3,Fs,-60,1.75,attackTime,releaseTime);
compressor_out_R_band4 = compressor(Gate_out_R_band4,Fs,-40,2,attackTime,releaseTime);
compressor_out_R_band5 = compressor(Gate_out_R_band5,Fs,-30,2.25,attackTime,releaseTime);
compressor_out_R_band6 = compressor(Gate_out_R_band6,Fs,-30,2.5,attackTime,releaseTime);
compressor_out_R_band7 = compressor(Gate_out_R_band7,Fs,-60,2.75,attackTime,releaseTime);
compressor_out_R_band8 = compressor(Gate_out_R_band8,Fs,-40,3.5,attackTime,releaseTime);
compressor_out_R_band9 = compressor(Gate_out_R_band9,Fs,-40,3.5,attackTime,releaseTime);


Comp_out_LeftEar = compressor_out_L_band1+compressor_out_L_band2+compressor_out_L_band3+compressor_out_L_band4+...
    compressor_out_L_band5+compressor_out_L_band6+compressor_out_L_band7+compressor_out_L_band8+compressor_out_L_band9;
Comp_out_RightEar = compressor_out_R_band1+compressor_out_R_band2+compressor_out_R_band3+compressor_out_R_band4+...
    compressor_out_R_band5+compressor_out_R_band6+compressor_out_R_band7+compressor_out_R_band8+compressor_out_R_band9;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%TINNITUS SCRIPT: Research suggests that tinnitus normally falls within the
%region where hearing loss is most pronounced. For best results follow
%this guidance.

% awgn adds white gaussian noise to the signal.
% Parameters - awgn(input,signal to noise,signal power)
% 'measured' - The signal level of in is computed to determine 
% the appropriate noise level based on the value of snr.

Noise_L = awgn(Comp_out_LeftEar, 20,'measured');
Noise_R = awgn(Comp_out_RightEar, 20,'measured');


%Parametric Equaliser to mimic Critical Band. Use the following formula to
%calculate the bandwidth: ERB = 24.7(0.00437fc+1)
% e.g ERB = 24.7(0.00437x10000+1) = 1104.09 Hz
% 1104/2 = 552 Hz
% This will be the upper and lower limits of the critical band.
% Plot the MPEQ to show the ERB filter(s).


Filter_L = multibandParametricEQ(...
    'NumEQBands',1, ...
    'Frequencies',3500, ... %Centre Frequency for Tinnitus Left Ear
    'PeakGains',10,...
    'QualityFactors',[5],...
    'HasHighpassFilter',true,...
    'HighpassSlope',24,...
    'HighpassCutoff', 3700,... %Critical Band f1
    'HasLowpassFilter',true,...
    'LowpassSlope', 48,...
    'LowpassCutoff',3300); %Critical Band f2

Filter_R = multibandParametricEQ(...
    'NumEQBands',1, ...
    'Frequencies',3500, ... %Centre Frequency for Tinnitus Right Ear
    'PeakGains',10,...
    'QualityFactors',[5],...
    'HasHighpassFilter',true,...
    'HighpassSlope',24,...
    'HighpassCutoff', 3700,... %Critical Band f1
    'HasLowpassFilter',true,...
    'LowpassSlope', 48,...
    'LowpassCutoff',3300); %Critical band f2

%mPEQ1 = Filter_L;
%mPEQ2 = Filter_R;
%visualize(mPEQ1)
%visualize(mPEQ2)
  
TinnitusOut_L = Filter_L(Noise_L);
TinnitusOut_R = Filter_R(Noise_R);

%TinnitusMain = TinnitusOut_L+TinnitusOut_R;

%sound(out,Fs);
%sound(in,Fs); % For comparison


%Output summing

out_LeftEar = Comp_out_LeftEar;
out_RightEar = Comp_out_RightEar;

Tinnitus_LEar = Comp_out_LeftEar+TinnitusOut_L;
Tinnitus_REar = Comp_out_RightEar+TinnitusOut_R;
TinnitusMain = Tinnitus_LEar+Tinnitus_REar;

HearingLoss_Tinnitus_MainOut = out_LeftEar+out_RightEar;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%HEARING AID CORRECTION STAGE


%Noise reduction Algorithm - adds white noise to the signal before decomposing the
%signal.

HearingLoss_Tinnitus_MainOut = HearingLoss_Tinnitus_MainOut * 0.5 / rms(HearingLoss_Tinnitus_MainOut);%Normalise signal

x = HearingLoss_Tinnitus_MainOut;
x = awgn(x,12,'measured'); % Add noise to the signal
[c,l] = wavedec(HearingLoss_Tinnitus_MainOut, 3, 'db4'); %Decompose signal
denoise = wthresh(c,'s',0.05); %Denoise signal using soft threshold
denoisedsignal = waverec(denoise,l,'db4'); %Reconstruct signal
denoisedsignal = denoisedsignal * 0.5/rms(denoisedsignal); %Normalise denoised signal

figure
plot(HearingLoss_Tinnitus_MainOut)
figure
plot(denoisedsignal);

%Frequency Shaper Function  - taken from....Varma et al,.(2021)
% x - an input sound signal
% g - the maximum gain that will be applied to the signal
% transitionV - 4 element vector that has the values of where the gain changes
%to the next piecewise function, values can be selcted to match the range
%where hearing loss is most prevelant.
% Fs - the sampling frequency of the input signal

g = 50;
transitionV = [1000, 2000, 3000, 8000];

HLShape = freqshape(denoisedsignal,g,transitionV,Fs);

%Dynamic Processing/Amplification

% Initialize separate attack and release times
attackTime = 0.005;  % time in seconds
releaseTime = 0.25;  % time in seconds

HearingAid_Compression = compressor(HLShape,Fs,-25,2,attackTime,releaseTime);

HearingAid_Ouput = HearingAid_Compression+TinnitusOut_L+TinnitusOut_R;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Outputs

audioOut3 = out_LeftEar+out_RightEar; %Hearing Loss Only
audioOut1 = TinnitusMain; %Hearing Loss with Tinnitus Only
audioOut2 = HearingAid_Ouput; %Outputs Hearing Loss with tinnitus and with Hearing AidCorrection
audioOut4 = HearingAid_Compression; %Outputs Hearing Loss and Hearing Aid correction only

%Output and Write - Change audio write file name to write a new file.

sound(audioOut2,Fs);
%sound(audioOut3,Fs);
audiowrite('HLS_Simulation_NIHL_AF_Tinn_HA.wav',audioOut2,Fs)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

